--------------------------------------------------------
--  File created - Monday-December-11-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for DB Link OBELIX_BACKUP.FRI.UNIZA.SK
--------------------------------------------------------

  CREATE DATABASE LINK "OBELIX_BACKUP.FRI.UNIZA.SK"
   CONNECT TO "ISTVANKO_SP" IDENTIFIED BY VALUES ':1'
   USING '(DESCRIPTION =
                        (ADDRESS = (PROTOCOL = TCP)(HOST = obelix.fri.uniza.sk)(PORT = 1521))
                        (CONNECT_DATA =
                          (SERVER = DEDICATED)
                          (SERVICE_NAME = orcl.fri.uniza.sk)
                        )
                     )';
--------------------------------------------------------
--  DDL for Type T_INSERT_PRESCRIPTION
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ISTVANKO_SP"."T_INSERT_PRESCRIPTION" AS OBJECT 
(
    drug_code VARCHAR2(5),
    dosage NUMBER
);


/
--------------------------------------------------------
--  DDL for Type T_INSERT_PRESCRIPTION_N_TABLE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ISTVANKO_SP"."T_INSERT_PRESCRIPTION_N_TABLE" AS TABLE OF t_insert_prescription;


/
--------------------------------------------------------
--  DDL for Type T_PERSON
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ISTVANKO_SP"."T_PERSON" IS OBJECT 
(
    name VARCHAR2(20),
    surname VARCHAR2(30),
    address VARCHAR2(50),
    email VARCHAR2(65)
);


/
--------------------------------------------------------
--  DDL for Type T_REC_VACCINATION_HIS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ISTVANKO_SP"."T_REC_VACCINATION_HIS" AS OBJECT (
    vaccination_id integer,
    vaccine_name VARCHAR2(100),
    vaccination_date DATE,
    vaccination_next_date DATE,
    vaccination_dose VARCHAR2(100)
);


/
--------------------------------------------------------
--  DDL for Type T_REC_VACCINATION_HIS_SAVE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TYPE "ISTVANKO_SP"."T_REC_VACCINATION_HIS_SAVE" AS OBJECT (
    vaccination_id integer,
    vaccine_name VARCHAR2(100),
    vaccination_date DATE,
    vaccination_next_date DATE,
    vaccination_dose VARCHAR2(100)
);

/
--------------------------------------------------------
--  DDL for Type T_VACCINATION_HIS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TYPE "ISTVANKO_SP"."T_VACCINATION_HIS" is table of t_rec_vaccination_his;


/
--------------------------------------------------------
--  DDL for Sequence APPOINTMENT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."APPOINTMENT_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence CARD_ID_GEN
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."CARD_ID_GEN"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 45341 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence CARD_ID_GEN2
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."CARD_ID_GEN2"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 8438 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence HOSPITAL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."HOSPITAL_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence MEDICAL_CARD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."MEDICAL_CARD_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence MEDICAL_RECORD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."MEDICAL_RECORD_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 6741 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence NEWIEE_CARD_ID
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."NEWIEE_CARD_ID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 8478 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence NEWIE_CARD_ID
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."NEWIE_CARD_ID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 8598 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence PATIENT_IN_WARD_ROOM_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."PATIENT_IN_WARD_ROOM_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 11921 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence PATIENT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."PATIENT_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 122600 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence PRESCRIBED_DRUGS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."PRESCRIBED_DRUGS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 122821 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence PRESCRIPTION_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."PRESCRIPTION_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 54241 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence SEQ_ID
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."SEQ_ID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence STAFF_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."STAFF_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 504040 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence VACCINATION_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "ISTVANKO_SP"."VACCINATION_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 65 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Index DRUG_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."DRUG_PK" ON "ISTVANKO_SP"."DRUG" ("DRUG_CODE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index HOSPITAL_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."HOSPITAL_PK" ON "ISTVANKO_SP"."HOSPITAL" ("HOSPITAL_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index MEDICAL_OCCUPATION_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."MEDICAL_OCCUPATION_PK" ON "ISTVANKO_SP"."MEDICAL_OCCUPATION" ("MEDICAL_OCCUPATION_CODE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index MEDICAL_RECORD_IMAGE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."MEDICAL_RECORD_IMAGE_PK" ON "ISTVANKO_SP"."MEDICAL_RECORD_IMAGE" ("RECORD_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index MEDICAL_SPECIALITY_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."MEDICAL_SPECIALITY_PK" ON "ISTVANKO_SP"."MEDICAL_SPECIALITY" ("MEDICAL_SPECIALITY_CODE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index MEDICAL_WORKER_ROLE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."MEDICAL_WORKER_ROLE_PK" ON "ISTVANKO_SP"."MEDICAL_WORKER_ROLE" ("MEDICAL_WORKER_ROLE_CODE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index PATIENT_IN_WARD_ROOM_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."PATIENT_IN_WARD_ROOM_PK" ON "ISTVANKO_SP"."PATIENT_IN_WARD_ROOM" ("PATIENT_IN_WARD_ROOM_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index PATIENT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."PATIENT_PK" ON "ISTVANKO_SP"."PATIENT" ("PATIENT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index PERSON_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."PERSON_PK" ON "ISTVANKO_SP"."PERSON" ("BIRTH_NUMBER") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index PRESCRIBED_DRUGS
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."PRESCRIBED_DRUGS" ON "ISTVANKO_SP"."PRESCRIBED_DRUGS" ("PRESCRIBED_DRUGS_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index PRESCRIPTION_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."PRESCRIPTION_PK" ON "ISTVANKO_SP"."PRESCRIPTION" ("PRESCRIPTION_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index STAFF_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."STAFF_PK" ON "ISTVANKO_SP"."STAFF" ("STAFF_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index USERS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ISTVANKO_SP"."USERS_PK" ON "ISTVANKO_SP"."USERS" ("USER_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index PATIENT_HOSPITAL_ID_INDEX
--------------------------------------------------------

  CREATE INDEX "ISTVANKO_SP"."PATIENT_HOSPITAL_ID_INDEX" ON "ISTVANKO_SP"."PATIENT" ("PATIENT_ID", "HOSPITAL_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index MEDICAL_CARD_BLOOD_TYPE_INDEX
--------------------------------------------------------

  CREATE INDEX "ISTVANKO_SP"."MEDICAL_CARD_BLOOD_TYPE_INDEX" ON "ISTVANKO_SP"."MEDICAL_CARD" ("BLOOD_TYPE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index SYS_FK0000372532N00007$
--------------------------------------------------------

  CREATE INDEX "ISTVANKO_SP"."SYS_FK0000372532N00007$" ON "ISTVANKO_SP"."VACCINATION_HISTORY_STORAGE_TABLE" ("NESTED_TABLE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Index MEDICAL_RECORD_BLOOD_TYPES_INDEX
--------------------------------------------------------

  CREATE INDEX "ISTVANKO_SP"."MEDICAL_RECORD_BLOOD_TYPES_INDEX" ON "ISTVANKO_SP"."MEDICAL_RECORD" (TO_NUMBER("MEDICAL_PROCEDURE_CODE"), EXTRACT(YEAR FROM "DATE_OF_ENTRY")) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "STUDENTI_PDBS_2023" ;
--------------------------------------------------------
--  DDL for Procedure ADD_APPOINTMENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."ADD_APPOINTMENT" (
    p_date_examination IN VARCHAR2,
    p_patient_id IN NUMBER,
    p_examination_location_code IN VARCHAR2,
    p_examination_type IN VARCHAR2,
    p_medical_procedure_code IN VARCHAR2
)
AS
    v_appointment_id NUMBER;
    v_formatted_date DATE;
BEGIN

    v_formatted_date := TO_DATE(p_date_examination, 'DD/MM/YYYY HH24:MI:SS');
    v_appointment_id := ISTVANKO_SP.APPOINTMENT_SEQ.NEXTVAL;

    INSERT INTO ISTVANKO_SP.APPOINTMENT (
        APPOINTMENT_ID,
        DATE_EXAMINATION,
        PATIENT_ID,
        EXAMINATION_LOCATION_CODE,
        EXAMINATION_TYPE,
        MEDICAL_PROCEDURE_CODE
    ) VALUES (
        v_appointment_id,
        v_formatted_date,
        p_patient_id,
        p_examination_location_code,
        p_examination_type,
        p_medical_procedure_code
    );
    COMMIT;
END;

/
--------------------------------------------------------
--  DDL for Procedure ADD_EXAMINATION_ROOM
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."ADD_EXAMINATION_ROOM" (p_examination_location_code CHAR, p_name_room VARCHAR, p_department_location_code CHAR, p_doctor_id INTEGER, p_nurse_id INTEGER)   
IS
  examination_room_count INTEGER;
BEGIN  
  SELECT COUNT(*) INTO examination_room_count FROM examination_room WHERE examination_location_code = p_examination_location_code;
  IF (examination_room_count = 0) THEN
    INSERT INTO examination_room VALUES(p_examination_location_code, p_name_room, p_department_location_code ,p_doctor_id,
       p_nurse_id, null);
       commit;
  ELSE
    rollback;
     RAISE_APPLICATION_ERROR(-20001,' '||p_examination_location_code ||' '||'does exist');
  END IF;
END;

/
--------------------------------------------------------
--  DDL for Procedure ADD_EXAMINATION_ROOM_WITH_SUPPLIES
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."ADD_EXAMINATION_ROOM_WITH_SUPPLIES" (p_examination_location_code CHAR, p_name_room VARCHAR, p_department_location_code CHAR, p_doctor_id INTEGER, p_nurse_id INTEGER, p_supplies VARCHAR2)   
IS
  examination_room_count INTEGER;
BEGIN  
  SELECT COUNT(*) INTO examination_room_count FROM examination_room WHERE examination_location_code = p_examination_location_code;
  IF (examination_room_count = 0) THEN
    INSERT INTO examination_room VALUES(p_examination_location_code, p_name_room, p_department_location_code ,p_doctor_id,
       p_nurse_id, TO_CLOB(p_supplies));
       commit;
  ELSE
    rollback;
     RAISE_APPLICATION_ERROR(-20001,' '||p_examination_location_code ||' '||'does exist');     
  END IF;
END;

/
--------------------------------------------------------
--  DDL for Procedure ADD_PATIENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."ADD_PATIENT" (p_birth_number VARCHAR, p_name VARCHAR, p_surname VARCHAR, p_postal_code CHAR, p_hospital_id INTEGER, p_address VARCHAR, p_email VARCHAR, p_date_from DATE, p_date_to DATE, p_doctor_id INTEGER)    
IS
    person_count INTEGER;
    patient_count INTEGER;
    patient_seq_val INTEGER;
BEGIN  
    SELECT COUNT(*) INTO person_count FROM person WHERE birth_number = p_birth_number;
    IF (person_count = 0) THEN
        INSERT INTO person VALUES(p_birth_number, p_postal_code, t_person(p_name, p_surname, p_address, p_email));
        INSERT INTO person_type@obelix_backup VALUES(p_birth_number, p_postal_code, p_name, p_surname, p_address, p_email);
    END IF;

    SELECT COUNT(*) INTO patient_count FROM patient WHERE birth_number = p_birth_number;
    IF (patient_count = 0) THEN
        patient_seq_val := patient_seq.nextval;
        INSERT INTO patient VALUES(patient_seq_val, p_birth_number, TO_DATE(p_date_from, 'DD/MM/YYYY HH24:MI:SS'), TO_DATE(p_date_to, 'DD/MM/YYYY HH24:MI:SS'), p_hospital_id);
        INSERT INTO patient@obelix_backup VALUES(patient_seq_val, p_birth_number, TO_DATE(p_date_from, 'DD/MM/YYYY HH24:MI:SS'), TO_DATE(p_date_to, 'DD/MM/YYYY HH24:MI:SS'), p_hospital_id);
        INSERT INTO medical_card VALUES (medical_card_seq.nextval, patient_seq_val, null, TO_DATE(p_date_from, 'DD/MM/YYYY HH24:MI:SS'), null, p_doctor_id, T_VACCINATION_HIS());
    END IF;
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END;

/
--------------------------------------------------------
--  DDL for Procedure ADD_UPDATE_PATIENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."ADD_UPDATE_PATIENT" (
    p_birth_number VARCHAR, 
    p_name VARCHAR, 
    p_surname VARCHAR, 
    p_postal_code CHAR, 
    p_hospital_id INTEGER, 
    p_address VARCHAR, 
    p_email VARCHAR, 
    p_date_from VARCHAR, 
    p_date_to VARCHAR
)    
IS
    person_count INTEGER;
    patient_count INTEGER;
BEGIN  
    SELECT COUNT(*) INTO person_count FROM person WHERE birth_number = p_birth_number;
    IF (person_count = 0) THEN
        INSERT INTO person VALUES(p_birth_number, p_postal_code, t_person(p_name, p_surname, p_address, p_email));
    ELSE
        UPDATE person SET postal_code = p_postal_code, person_info = t_person(p_name, p_surname, p_address, p_email) WHERE birth_number = p_birth_number;
    END IF;

    SELECT COUNT(*) INTO patient_count FROM patient WHERE birth_number = p_birth_number;
    IF (patient_count = 0) THEN
        INSERT INTO patient VALUES(patient_seq.nextval, p_birth_number, TO_DATE(TO_CHAR(TO_TIMESTAMP(p_date_from, 'DD/MM/YYYY HH24:MI:SS'), 'DD/MM/YYYY HH24:MI:SS')),
            TO_DATE(TO_CHAR(TO_TIMESTAMP(p_date_to, 'DD/MM/YYYY HH24:MI:SS'), 'DD/MM/YYYY HH24:MI:SS')), p_hospital_id);
    ELSE
        UPDATE patient SET date_from = TO_DATE(TO_CHAR(TO_TIMESTAMP(p_date_from, 'DD/MM/YYYY HH24:MI:SS'), 'DD/MM/YYYY HH24:MI:SS')), 
            date_to = TO_DATE(TO_CHAR(TO_TIMESTAMP(p_date_to, 'DD/MM/YYYY HH24:MI:SS'), 'DD/MM/YYYY HH24:MI:SS')), 
            hospital_id = p_hospital_id 
        WHERE birth_number = p_birth_number;
    END IF;
    COMMIT;
END;

/
--------------------------------------------------------
--  DDL for Procedure CHECK_JSON_KEY_EXISTS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."CHECK_JSON_KEY_EXISTS" (
    p_key VARCHAR2,
    p_json CLOB
)
IS
    v_count NUMBER;
    v_sql VARCHAR2(1000);
BEGIN
    -- Construct the dynamic SQL query
    v_sql := 'SELECT COUNT(*) FROM DUAL WHERE JSON_EXISTS(:json, ''$ ? (@ == "' || p_key || '")'')';

    -- Execute the dynamic SQL query
    EXECUTE IMMEDIATE v_sql INTO v_count USING p_json;

    -- Check the result
    IF v_count > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Key ''' || p_key || ''' exists in the JSON.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Key ''' || p_key || ''' does not exist in the JSON.');
    END IF;
END;

/
--------------------------------------------------------
--  DDL for Procedure DELETE_EXAMINATION_ROOM
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."DELETE_EXAMINATION_ROOM" (p_examination_location_code CHAR)   
IS
  examination_room_count INTEGER;
BEGIN  
  SELECT COUNT(*) INTO examination_room_count FROM examination_room WHERE examination_location_code = p_examination_location_code;
  IF (examination_room_count > 0) THEN
    delete from examination_room
    where examination_location_code = p_examination_location_code;
    commit;
  ELSE
    rollback;
     RAISE_APPLICATION_ERROR(-20001,' '||p_examination_location_code ||' '||'does not exist'); 
  END IF;
END;

/
--------------------------------------------------------
--  DDL for Procedure DELETE_PRESCRIPTION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ISTVANKO_SP"."DELETE_PRESCRIPTION" (p_prescription_id NUMBER) 
IS
BEGIN
    DELETE FROM prescribed_drugs WHERE prescription_id = p_prescription_id;
    DELETE FROM prescription WHERE prescription_id = p_prescription_id;
    commit;
END;


/
--------------------------------------------------------
--  DDL for Procedure DELETE_SUPPLY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."DELETE_SUPPLY" (p_name VARCHAR, p_roomCode VARCHAR)
IS
BEGIN  
    UPDATE examination_room e
             SET e.supplies = JSON_MERGEPATCH(
                                 e.supplies,
                                 '{"' || p_name || '":  null  }'
                              )
             WHERE e.EXAMINATION_LOCATION_CODE = p_roomCode;
    COMMIT;
END;

/
--------------------------------------------------------
--  DDL for Procedure DELETE_VACCINATION_FOR_PATIENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ISTVANKO_SP"."DELETE_VACCINATION_FOR_PATIENT" (
    p_vaccine_id INTEGER, 
    p_patient_id INTEGER)
IS
BEGIN   
    DELETE FROM TABLE(SELECT mc.vaccination_history FROM medical_card mc WHERE mc.patient_id = p_patient_id) vac_hist
    WHERE vac_hist.vaccination_id = p_vaccine_id;
    commit;
END;


/
--------------------------------------------------------
--  DDL for Procedure GET_THE_MOST_PRESCRIBED_DRUG_PER_YEAR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."GET_THE_MOST_PRESCRIBED_DRUG_PER_YEAR" (p_year Integer,p_hospital INTEGER)   
IS
begin 
  select drug_code, drug_count, name
    from (
            select  prescribed_drugs.drug_code,drug.name as name,
                    count(prescribed_drugs.prescribed_drugs_id) AS drug_count,
                    rank() over (order by count(prescribed_drugs_id) desc) as rnk
                from drug
                join prescribed_drugs ON drug.drug_code = prescribed_drugs.drug_code
                join prescription ON prescribed_drugs.prescribed_drugs_id = prescription.prescription_id
                join staff USING (staff_id)
            where staff.hospital_id = p_hospital  and to_char(prescription.DATE_ISSUED, 'YYYY') = p_year 
            group by prescribed_drugs.drug_code,drug.name

)
where rnk =1;
end;

/
--------------------------------------------------------
--  DDL for Procedure INSERT_MEDICAL_RECORD
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ISTVANKO_SP"."INSERT_MEDICAL_RECORD" (
    p_record_id INTEGER, 
    p_notes VARCHAR2,
    p_test_result VARCHAR2,
    p_medical_procedure_code VARCHAR2,
    p_diagnose_code VARCHAR2,
    p_patient_id INTEGER,
    p_doctor_id INTEGER,
    p_blob_data BLOB,
    p_file_name VARCHAR2,
    p_mime_type VARCHAR2
)
IS
    v_medical_record_image_id INTEGER;
    v_file_name VARCHAR2(100);
    patient_card_id INTEGER;
    new_record_id INTEGER;
BEGIN
    -- if record is set, update record
    IF p_record_id IS NOT NULL THEN
        UPDATE 
            medical_record mr
        SET
            notes = p_notes,
            test_result = p_test_result,
            medical_procedure_code = p_medical_procedure_code,
            diagnose_code = p_diagnose_code,
            date_of_update = sysdate
        WHERE 
            mr.record_id = p_record_id;

        -- check if there is image
        IF DBMS_LOB.getlength(p_blob_data) > 1 THEN
            SELECT 
                record_id 
            INTO
                v_medical_record_image_id
            FROM 
                medical_record_image 
            WHERE 
                record_id = p_record_id;

            -- if there is no file name set it to record_id
            IF LENGTH(p_file_name) = 0 THEN
                v_file_name := p_record_id;
            ELSE 
                v_file_name := p_file_name;
            END IF;

            -- if v_medical_record_image_id is not null, image is in the database
            -- else we just insert new image
            IF v_medical_record_image_id IS NOT NULL THEN
                UPDATE 
                    medical_record_image 
                SET 
                    file_name = v_file_name,
                    image = p_blob_data
                WHERE 
                    record_id = p_record_id;
            ELSE 
                INSERT INTO medical_record_image VALUES (p_record_id, v_file_name, p_blob_data, p_mime_type); 
            END IF; 
        END IF;

    -- record is not set, insert new record
    ELSE         
        BEGIN
            SELECT 
                mc.card_id
            INTO 
                patient_card_id
            FROM 
                medical_card mc
            WHERE 
                mc.date_until IS NULL
                AND mc.patient_id = p_patient_id;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR( -20001, 'Patient card does not exist' );
        END;

        new_record_id := medical_record_seq.nextval;

        INSERT INTO medical_record VALUES (new_record_id, sysdate, p_notes, p_test_result, p_medical_procedure_code, p_diagnose_code, patient_card_id, p_doctor_id, null);

        IF DBMS_LOB.getlength(p_blob_data) > 1 THEN
            IF LENGTH(p_file_name) = 0 THEN
                v_file_name := new_record_id;
            ELSE 
                v_file_name := p_file_name;
            END IF;

            INSERT INTO medical_record_image VALUES (new_record_id, v_file_name, p_blob_data, p_mime_type); 
        END IF;
    END IF;

    commit;
END;


/
--------------------------------------------------------
--  DDL for Procedure INSERT_PRESCRIPTION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."INSERT_PRESCRIPTION" (
    p_drugs t_insert_prescription_n_table,
    p_staff_id INTEGER,
    p_patient_id INTEGER,
    p_diagnose_code VARCHAR2,
    p_date_expiry DATE
)
AS
    v_prescription_id INTEGER;
BEGIN
    v_prescription_id := prescription_seq.nextval;
    INSERT INTO prescription
    VALUES (v_prescription_id, SYSDATE, TO_DATE(p_date_expiry, 'DD.MM.YYYY'), p_patient_id, p_diagnose_code, p_staff_id);

    IF p_drugs IS NOT NULL AND p_drugs.COUNT > 0 THEN
        FOR i IN 1..p_drugs.LAST LOOP
            INSERT INTO prescribed_drugs
            VALUES (prescribed_drugs_seq.nextval, p_drugs(i).drug_code, v_prescription_id, p_drugs(i).dosage);
        END LOOP;
    END IF;

    commit;
END;

/
--------------------------------------------------------
--  DDL for Procedure INSERT_SUPPLY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."INSERT_SUPPLY" (
    p_name VARCHAR2,
    p_quantity INTEGER,
    p_roomCode VARCHAR2
)
IS
    v_result NUMBER;
BEGIN 
    EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM examination_room e WHERE e.EXAMINATION_LOCATION_CODE = :p_roomCode AND JSON_EXISTS(e.supplies, ''$."' || p_name || '"'')'
    INTO v_result
    USING p_roomCode;

    -- Check the result
         IF v_result > 0 THEN
            RAISE_APPLICATION_ERROR(-20001,' '||p_name ||' '||'does exist in supplies');
            ROLLBACK;
            -- DBMS_OUTPUT.PUT_LINE('The key ' || p_name || ' with quantity ' || p_quantity || ' already exists in supplies.');
        ELSE
            --DBMS_OUTPUT.PUT_LINE('The key ' || p_name || ' with quantity ' || p_quantity || ' dont already exists in supplies.');
           UPDATE examination_room e
                   SET e.supplies = JSON_MERGEPATCH(
                                        e.supplies,
                                       '{"' || p_name || '": ' || p_quantity || '}'
                                     )
                    WHERE e.EXAMINATION_LOCATION_CODE = p_roomCode;
                    COMMIT;
        END IF;         
END;

/
--------------------------------------------------------
--  DDL for Procedure INSERT_VACCINATION_TO_PATIENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."INSERT_VACCINATION_TO_PATIENT" (
    p_vaccine_id INTEGER, 
    p_patient_id INTEGER, 
    p_type_vaccination INTEGER, 
    p_date_vaccination DATE, 
    p_date_re_vaccination DATE, 
    p_vaccine_dose INTEGER)
IS
    v_type_vaccination VARCHAR2(100);
    v_vaccine_dose VARCHAR2(100);
    v_vaccination_history t_vaccination_his;
BEGIN
    SELECT 
        vaccination_history
    INTO 
        v_vaccination_history
    FROM 
        medical_card 
    WHERE 
        patient_id = p_patient_id;

    IF p_vaccine_id IS NOT NULL THEN
        SELECT 
            vaccine_dose_type
        INTO 
            v_vaccine_dose
        FROM 
            vaccine_dose
        WHERE 
            vaccine_dose_id = p_vaccine_dose;

        SELECT
            vaccine_name
        INTO
            v_type_vaccination
        FROM
            vaccine
        WHERE vaccine_id = p_type_vaccination;

        UPDATE TABLE (SELECT mc.vaccination_history FROM medical_card mc WHERE mc.patient_id = p_patient_id)
        SET 
            vaccine_name = v_type_vaccination,
            vaccination_date = p_date_vaccination,
            vaccination_next_date = p_date_re_vaccination,
            vaccination_dose = v_vaccine_dose
        WHERE vaccination_id = p_vaccine_id;

    ELSE
        SELECT 
            vaccine_dose_type
        INTO 
            v_vaccine_dose
        FROM 
            vaccine_dose
        WHERE 
            vaccine_dose_id = p_vaccine_dose;

        SELECT
            vaccine_name
        INTO
            v_type_vaccination
        FROM
            vaccine
        WHERE vaccine_id = p_type_vaccination;

        SELECT 
            mc.vaccination_history
        INTO
            v_vaccination_history
        FROM 
            medical_card mc 
        WHERE 
            mc.patient_id = p_patient_id;

        v_vaccination_history.extend();
        v_vaccination_history(v_vaccination_history.last) := t_rec_vaccination_his(
                vaccination_seq.nextval,
                v_type_vaccination,
                p_date_vaccination,
                p_date_re_vaccination,
                v_vaccine_dose
            );

        UPDATE medical_card
        SET vaccination_history = v_vaccination_history
        WHERE patient_id = p_patient_id;
    END IF;

    commit;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END;

/
--------------------------------------------------------
--  DDL for Procedure P_BIRTH_DATE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."P_BIRTH_DATE" (p_birth_number VARCHAR2, p_result_date OUT DATE)
IS
  month_date INTEGER;
BEGIN
  IF SUBSTR(p_birth_number, 3, 1) IN (2, 3, 7, 8) THEN
  DBMS_OUTPUT.PUT_LINE(SUBSTR(p_birth_number, 3, 2));
  DBMS_OUTPUT.PUT_LINE('to number');
  DBMS_OUTPUT.PUT_LINE(TO_NUMBER(SUBSTR(p_birth_number, 3, 2)));
    month_date := TO_NUMBER(SUBSTR(p_birth_number, 3, 2)) - 20;
    DBMS_OUTPUT.PUT_LINE(month_date);
  ELSE
    month_date := TO_NUMBER(SUBSTR(p_birth_number, 3, 2));
    DBMS_OUTPUT.PUT_LINE(month_date);
  END IF;

  DBMS_OUTPUT.PUT_LINE(month_date);

  IF TO_NUMBER(SUBSTR(p_birth_number, 1, 2)) <= TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE, 'YYYY'), 3, 2)) THEN  
    p_result_date := TO_DATE(SUBSTR(p_birth_number, 5, 2) || '.' || MOD(month_date, 50) || '.20' || SUBSTR(p_birth_number, 1, 2), 'DD.MM.YYYY');
  ELSE
    p_result_date := TO_DATE(SUBSTR(p_birth_number, 5, 2) || '.' || MOD(month_date, 50) || '.19' || SUBSTR(p_birth_number, 1, 2), 'DD.MM.YYYY');
  END IF;

  DBMS_OUTPUT.PUT_LINE(p_result_date);
END;

/
--------------------------------------------------------
--  DDL for Procedure SEED_HOSPITAL1_SPACE_DATA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."SEED_HOSPITAL1_SPACE_DATA" IS
    v_patient_id PATIENT.PATIENT_ID%TYPE;
    v_location_code WARD_ROOM.ROOM_LOCATION_CODE%TYPE;
    v_date_from DATE;
    v_date_until DATE;
    v_max_days NUMBER := 21; -- Maximum stay duration in days
    v_min_days NUMBER := 1;  -- Minimum stay duration in days
BEGIN
    FOR r IN (
        SELECT p.patient_id
        FROM patient p
        JOIN department d ON p.hospital_id = d.hospital_id
        WHERE p.hospital_id = 1 AND ROWNUM <= 100
        ORDER BY DBMS_RANDOM.VALUE
    ) LOOP
        v_patient_id := r.patient_id;

        -- Randomly select a ward room in the same hospital that has free space
        SELECT room_location_code INTO v_location_code
        FROM (
            SELECT wr.room_location_code
            FROM ward_room wr
            JOIN department d ON wr.department_location_code = d.department_location_code
            WHERE d.hospital_id = 1 AND wr.room_capacity > (
                SELECT COUNT(*) FROM patient_in_ward_room pwr
                WHERE pwr.location_code = wr.room_location_code
                  AND pwr.date_from <= SYSDATE
                  AND (pwr.date_until IS NULL OR pwr.date_until >= SYSDATE)
            )
            ORDER BY DBMS_RANDOM.VALUE
        )
        WHERE ROWNUM = 1;

        -- Randomly set the start date to the previous day and duration of stay within 1 to 21 days
        v_date_from := TRUNC(SYSDATE) - 1; -- Starts from the previous day
        v_date_until := v_date_from + DBMS_RANDOM.VALUE(v_min_days, v_max_days); -- Duration from 1 to 21 days

        -- Insert the patient into the ward room
        INSERT INTO patient_in_ward_room (patient_in_ward_room_id, patient_id, location_code, date_from, date_until)
        VALUES (patient_in_ward_room_seq.NEXTVAL, v_patient_id, v_location_code, v_date_from, v_date_until);
    END LOOP;

    COMMIT;
END seed_hospital1_space_data;

/
--------------------------------------------------------
--  DDL for Procedure UPDATE_EXAMINATION_ROOM
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."UPDATE_EXAMINATION_ROOM" (p_examination_location_code CHAR, p_name_room VARCHAR, p_department_location_code CHAR, p_doctor_id INTEGER, p_nurse_id INTEGER)   
IS
BEGIN  
   UPDATE examination_room
   SET name_room = p_name_room,
        department_location_code = p_department_location_code,
        doctor_id = p_doctor_id,
        nurse_id = p_nurse_id
   WHERE examination_location_code = p_examination_location_code;      
  COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;  
END;

/
--------------------------------------------------------
--  DDL for Procedure UPDATE_PATIENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."UPDATE_PATIENT" (
    p_patient_id INTEGER,
    p_birth_number VARCHAR, 
    p_name VARCHAR, 
    p_surname VARCHAR, 
    p_postal_code CHAR, 
    p_hospital_id INTEGER, 
    p_address VARCHAR, 
    p_email VARCHAR, 
    p_date_from VARCHAR
)    
IS
BEGIN  
    UPDATE person 
    SET postal_code = p_postal_code, 
        person_info = t_person(p_name, p_surname, p_address, p_email) 
    WHERE birth_number = p_birth_number;

    UPDATE patient 
    SET birth_number = p_birth_number, 
        date_from = TO_DATE(p_date_from, 'DD/MM/YYYY HH24:MI:SS'),
        hospital_id = p_hospital_id
    WHERE patient_id = p_patient_id;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;
END;

/
--------------------------------------------------------
--  DDL for Procedure UPDATE_SUPPLY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "ISTVANKO_SP"."UPDATE_SUPPLY" (p_name VARCHAR, p_quantity INTEGER, p_roomCode VARCHAR)
IS
v_count NUMBER;
BEGIN  
    SELECT COUNT(*)
    INTO v_count
    FROM examination_room
    WHERE EXAMINATION_LOCATION_CODE = p_roomCode AND supplies IS NULL;
  IF v_count > 0 THEN
        UPDATE examination_room
        SET supplies = '{"' || p_name || '": ' || p_quantity || '}'
        WHERE EXAMINATION_LOCATION_CODE = p_roomCode;
    ELSE
    UPDATE examination_room e
             SET e.supplies = JSON_MERGEPATCH(
                                 e.supplies,
                                 '{"' || p_name || '": ' || p_quantity || '}'
                              )
             WHERE e.EXAMINATION_LOCATION_CODE = p_roomCode;
    END IF;         
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE;     
END;

/
--------------------------------------------------------
--  DDL for Function F_BIRTH_DATE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."F_BIRTH_DATE" (p_birth_number VARCHAR2)
  RETURN DATE
IS
  birth_date DATE;
  month_date INTEGER;
BEGIN
      IF substr(p_birth_number,3,1) IN (2, 3, 7,8 ) THEN
        month_date := TO_NUMBER(SUBSTR(p_birth_number, 3, 2)) - 20;
      ELSE
          month_date := TO_NUMBER(SUBSTR(p_birth_number, 3, 2));
      END IF;
      IF TO_NUMBER(SUBSTR(p_birth_number, 1, 2)) <= TO_NUMBER(substr(to_char(sysdate, 'YYYY'),3,2)) THEN  
         birth_date := to_date(substr(p_birth_number,5,2) || '.' || mod(month_date,50) || '.20' || substr(p_birth_number,1,2), 'dd.mm.yyyy');
      ELSE
          birth_date := to_date(substr(p_birth_number,5,2) || '.' || mod(month_date,50) || '.19' || substr(p_birth_number,1,2), 'dd.mm.yyyy');
      END IF;
      RETURN birth_date;

EXCEPTION
  WHEN OTHERS THEN
    RETURN SYSDATE;
END;

/
--------------------------------------------------------
--  DDL for Function F_GET_AGE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "ISTVANKO_SP"."F_GET_AGE" (p_rod_cislo varchar)
RETURN integer
is 
datum date;
begin
    datum := f_birth_date(p_rod_cislo);
    return months_between(sysdate,datum)/12;
    exception when others then
    return -1;
end;

select * from examination_room where examination_location_code like'ZZ%';




/
--------------------------------------------------------
--  DDL for Function GENERATE_BIRTH_NUMBER
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."GENERATE_BIRTH_NUMBER" (p_birthdate DATE, p_gender CHAR, p_is_foreign BOOLEAN) RETURN VARCHAR2 IS
    v_date_part_year VARCHAR2(2);
    v_date_part_month VARCHAR2(2);
    v_date_part_day VARCHAR2(2);
    v_date_part VARCHAR2(6);
    v_control_digit NUMBER(4);
    v_birth_number VARCHAR2(11);
    v_is_old_system BOOLEAN;
BEGIN
    -- extract the date part in YYMMDD format from the birth date
    v_date_part_year := TO_CHAR(p_birthdate, 'YY');
    v_date_part_month := TO_CHAR(p_birthdate, 'MM');
    v_date_part_day := TO_CHAR(p_birthdate, 'DD');
    v_is_old_system := (p_birthdate < TO_DATE('1954-01-01', 'YYYY-MM-DD'));

    IF p_is_foreign THEN
        v_date_part_month := TO_NUMBER(v_date_part_month) + 20;
    END IF;

    IF p_gender = 'F' THEN
        v_date_part_month := TO_NUMBER(v_date_part_month) + 50;
    END IF;

    v_date_part := v_date_part_year || v_date_part_month || v_date_part_day;
    v_control_digit := generate_identificator_digits_for_birth_number(v_date_part, v_is_old_system);

    -- before 1954 the format is just with the unique part
    IF v_is_old_system THEN
        -- F - fill mode
        -- M - suppress the negative sign when converting a number to a character string
        -- 000 - number formatted with three digits
        v_birth_number := v_date_part || '/' || TO_CHAR(v_control_digit, 'FM000');
    ELSE
        v_birth_number := v_date_part || '/' || TO_CHAR(v_control_digit, 'FM0000');
    END IF;

    RETURN v_birth_number;
END generate_birth_number;


/
--------------------------------------------------------
--  DDL for Function GENERATE_IDENTIFICATOR_DIGITS_FOR_BIRTH_NUMBER
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."GENERATE_IDENTIFICATOR_DIGITS_FOR_BIRTH_NUMBER" (p_birth_date_part VARCHAR2, p_is_old_system BOOLEAN) RETURN NUMBER IS
    v_unique_part NUMBER(4);
    v_control_digit NUMBER(1) := -1;
BEGIN
    IF p_is_old_system THEN
        RETURN FLOOR(DBMS_RANDOM.VALUE(1, 999));
    END IF;

    -- when the modulo returns 10, the birth number cant be valid, that is the -1
    WHILE v_control_digit = -1 LOOP
        v_unique_part := FLOOR(DBMS_RANDOM.VALUE(1, 999));
        v_control_digit := modulo11(p_birth_date_part || TO_CHAR(v_unique_part, 'FM000'));
    END LOOP;

    RETURN v_unique_part || v_control_digit;
END;


/
--------------------------------------------------------
--  DDL for Function GETAPPOINTMENTSCOUNTBYDATE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."GETAPPOINTMENTSCOUNTBYDATE" (p_hospital_id IN NUMBER, p_date IN DATE DEFAULT TRUNC(SYSDATE))
RETURN NUMBER
IS
    appointments_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO appointments_count
    FROM appointment a
    JOIN examination_room er ON a.examination_location_code = er.examination_location_code
    JOIN department d ON er.department_location_code = d.department_location_code
    WHERE d.hospital_id = p_hospital_id
      AND TRUNC(a.date_examination) = p_date;

    RETURN appointments_count;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
    WHEN OTHERS THEN
        RAISE;
END GetAppointmentsCountByDate;


/
--------------------------------------------------------
--  DDL for Function GETDEPARTMENTUSAGEPERCENTAGE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."GETDEPARTMENTUSAGEPERCENTAGE" (p_date IN DATE DEFAULT SYSDATE)
RETURN SYS_REFCURSOR
IS
    rc SYS_REFCURSOR;
BEGIN
    OPEN rc FOR
        SELECT 
            d.name AS department_name,
            NVL(usage.total_patients, 0) AS patients_on_date,
            capacity.total_capacity,
            CASE 
                WHEN capacity.total_capacity > 0 THEN 
                    ROUND((NVL(usage.total_patients, 0) / capacity.total_capacity) * 100, 2)
                ELSE 
                    0
            END AS usage_percentage
        FROM 
            department d
        LEFT JOIN 
            (SELECT 
                 wr.department_location_code, 
                 SUM(wr.room_capacity) AS total_capacity
             FROM 
                 ward_room wr
             GROUP BY 
                 wr.department_location_code
            ) capacity ON d.department_location_code = capacity.department_location_code
        LEFT JOIN 
            (SELECT 
                 wr.department_location_code, 
                 COUNT(pwr.patient_id) AS total_patients
             FROM 
                 patient_in_ward_room pwr
             JOIN 
                 ward_room wr ON pwr.location_code = wr.room_location_code
             WHERE 
                 pwr.date_from <= p_date AND (pwr.date_until IS NULL OR pwr.date_until >= p_date)
             GROUP BY 
                 wr.department_location_code
            ) usage ON d.department_location_code = usage.department_location_code
        ORDER BY 
            d.name;

    RETURN rc;
END GetDepartmentUsagePercentage;


/
--------------------------------------------------------
--  DDL for Function GETFREESPACESINHOSPITAL
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."GETFREESPACESINHOSPITAL" (p_hospital_id IN NUMBER)
RETURN SYS_REFCURSOR
IS
    rc SYS_REFCURSOR;
BEGIN
    OPEN rc FOR
        SELECT 
            d.name AS department_name,
            d.hospital_id,
            SUM(wr.room_capacity) AS total_capacity,
            (SUM(wr.room_capacity) - COUNT(pwr.patient_id)) AS free_spaces
        FROM 
            department d
        JOIN 
            ward_room wr ON d.department_location_code = wr.department_location_code
        LEFT JOIN 
            patient_in_ward_room pwr ON wr.room_location_code = pwr.location_code
            AND pwr.date_from <= SYSDATE 
            AND (pwr.date_until IS NULL OR pwr.date_until >= SYSDATE)
        WHERE 
            d.hospital_id = p_hospital_id
        GROUP BY 
            d.name, d.hospital_id
        ORDER BY 
            d.name;

    RETURN rc;
END GetFreeSpacesInHospital;


/
--------------------------------------------------------
--  DDL for Function GETPATIENTADMISSIONSBYMONTH
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."GETPATIENTADMISSIONSBYMONTH" (p_year IN NUMBER, p_month IN NUMBER)
RETURN SYS_REFCURSOR
IS
    rc SYS_REFCURSOR;
BEGIN
    OPEN rc FOR
        SELECT 
            d.name AS department_name,
            pwr.date_from,
            COUNT(p.patient_id) OVER (PARTITION BY d.department_location_code ORDER BY pwr.date_from) AS running_total_admissions
        FROM 
            patient_in_ward_room pwr
        JOIN 
            ward_room wr ON pwr.location_code = wr.room_location_code
        JOIN 
            department d ON wr.department_location_code = d.department_location_code
        JOIN 
            patient p ON pwr.patient_id = p.patient_id
        WHERE
            EXTRACT(YEAR FROM pwr.date_from) = p_year AND
            EXTRACT(MONTH FROM pwr.date_from) = p_month
        ORDER BY 
            d.department_location_code, pwr.date_from;

    RETURN rc;
END GetPatientAdmissionsByMonth;


/
--------------------------------------------------------
--  DDL for Function GETTHEMOSTPRESCRIPEDDRUGPERYEAR
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "ISTVANKO_SP"."GETTHEMOSTPRESCRIPEDDRUGPERYEAR" (
    p_hospital_id NUMBER,
    p_year VARCHAR2
) RETURN SYS_REFCURSOR
IS
    v_result_cursor SYS_REFCURSOR;
BEGIN
    OPEN v_result_cursor FOR
        select drug_code, drug_count, name
    from (
            select  prescribed_drugs.drug_code,drug.name as name,
                    count(prescribed_drugs.prescribed_drugs_id) AS drug_count,
                    rank() over (order by count(prescribed_drugs_id) desc) as rnk
                from drug
                join prescribed_drugs ON drug.drug_code = prescribed_drugs.drug_code
                join prescription ON prescribed_drugs.prescribed_drugs_id = prescription.prescription_id
                join staff USING (staff_id)
            where staff.hospital_id = p_hospital_id  and to_char(prescription.DATE_ISSUED, 'YYYY') = p_year 
            group by prescribed_drugs.drug_code,drug.name

)
where rnk =1;

    RETURN v_result_cursor;
END GetTheMostPrescripedDrugPerYear;

/
--------------------------------------------------------
--  DDL for Function GETTODAYSAPPOINTMENTSCOUNT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."GETTODAYSAPPOINTMENTSCOUNT" (p_hospital_id IN NUMBER)
RETURN NUMBER
IS
    todays_appointments_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO todays_appointments_count
    FROM appointment a
    JOIN examination_room er ON a.examination_location_code = er.examination_location_code
    JOIN department d ON er.department_location_code = d.department_location_code
    WHERE d.hospital_id = p_hospital_id
      AND a.date_examination = TRUNC(SYSDATE);

    RETURN todays_appointments_count;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
    WHEN OTHERS THEN
        RAISE;
END GetTodaysAppointmentsCount;


/
--------------------------------------------------------
--  DDL for Function GETTOTALPATIENTADMISSIONSBYMONTH
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."GETTOTALPATIENTADMISSIONSBYMONTH" (p_year IN NUMBER, p_month IN NUMBER)
RETURN SYS_REFCURSOR
IS
    rc SYS_REFCURSOR;
BEGIN
    OPEN rc FOR
        SELECT 
            d.name AS department_name,
            COUNT(p.patient_id) AS total_admissions
        FROM 
            patient_in_ward_room pwr
        JOIN 
            ward_room wr ON pwr.location_code = wr.room_location_code
        JOIN 
            department d ON wr.department_location_code = d.department_location_code
        JOIN 
            patient p ON pwr.patient_id = p.patient_id
        WHERE
            EXTRACT(YEAR FROM pwr.date_from) = p_year AND
            EXTRACT(MONTH FROM pwr.date_from) = p_month
        GROUP BY 
            d.name
        ORDER BY 
            d.name;

    RETURN rc;
END GetTotalPatientAdmissionsByMonth;


/
--------------------------------------------------------
--  DDL for Function GET_APPOINTMENTS_COUNT_BY_DATE
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE FUNCTION "ISTVANKO_SP"."GET_APPOINTMENTS_COUNT_BY_DATE" (
    p_hospital_id IN NUMBER, 
    p_date IN DATE DEFAULT TRUNC(SYSDATE)
)
RETURN NUMBER
IS
    appointments_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO appointments_count
    FROM appointment a
    JOIN examination_room er ON a.examination_location_code = er.examination_location_code
    JOIN department d ON er.department_location_code = d.department_location_code
    WHERE d.hospital_id = p_hospital_id
      AND TRUNC(a.date_examination) = p_date;

    RETURN appointments_count;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 0;
    WHEN OTHERS THEN
        RAISE;
END GET_APPOINTMENTS_COUNT_BY_DATE;

/
--------------------------------------------------------
--  DDL for Function INSERT_PRESCRIPTION_F
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."INSERT_PRESCRIPTION_F" (
    p_drugs t_insert_prescription_n_table,
    p_staff_id INTEGER,
    p_patient_id INTEGER,
    p_diagnose_code VARCHAR2,
    p_date_expiry DATE
) RETURN VARCHAR2
AS
BEGIN
    RETURN p_drugs(1).drug_code;
END;


/
--------------------------------------------------------
--  DDL for Function MODULO11
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "ISTVANKO_SP"."MODULO11" (p_input_string IN VARCHAR2) RETURN NUMBER IS
    v_string VARCHAR2(15);
    v_number NUMBER(9);
BEGIN
    v_string := REPLACE(p_input_string, '/', '');
    v_number := TO_NUMBER(v_string);

    IF MOD(v_number, 11) = 10 THEN
        FOR control_number IN 1..9
        LOOP
            IF MOD(TO_NUMBER(v_number || control_number), 11) = 0 THEN
                RETURN control_number;
            END IF;
        END LOOP;

        RETURN -1;
    END IF;

    RETURN MOD(v_number, 11);
END modulo11;

/
